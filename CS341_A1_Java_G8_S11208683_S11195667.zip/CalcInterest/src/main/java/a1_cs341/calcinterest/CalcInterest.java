package a1_cs341.calcinterest;

import java.math.BigDecimal;
import java.math.RoundingMode;
public class CalcInterest {

    public static double computeLoanInterest(double loanAmount, int yearLoan, int loanType) {
        double interestRate = 0;
        if (loanAmount == 0 || yearLoan == 0){
            return -1;
        }else if(loanAmount < 1 || yearLoan < 1){
            return -1;
        }
        
        
        switch (loanType) {
            case 1 -> {
                // Home Loan
                if (loanAmount < 100000) {
                    if (yearLoan <= 5) {
                        interestRate = 8.0;
                    } else if (yearLoan >= 6 && yearLoan <= 10) {
                        interestRate = 6.5;
                    } else if (yearLoan >= 11) {
                        interestRate = 5.5;
                    }
                } else if (loanAmount >= 100000 && loanAmount < 500000) {
                    if (yearLoan <= 10) {
                        interestRate = 6.5;
                    }else{
                        return -1;
                    }
                } else if (loanAmount >= 500000 && yearLoan >= 11) {
                    interestRate = 5.5;
                }else{
                        return -1;
                    }
            }
            case 2 -> {
                // Property Loan
                if (loanAmount < 100000) {
                    if (yearLoan <= 5) {
                        interestRate = 12.0;
                    } else if (yearLoan >= 6 && yearLoan < 10) {
                        interestRate = 8.5;
                    } else if (yearLoan >= 11) {
                        interestRate = 7.0;
                    }else{
                        return -1;
                    }
                } else if (loanAmount >= 100000 && loanAmount < 500000) {
                    if (yearLoan < 10) {
                        interestRate = 8.5;
                    } else{
                        return -1;
                    }
                } else if (loanAmount >= 500000 && yearLoan >= 11) {
                    interestRate = 7.0;
                }else{
                    return -1;
                }
            }
            default -> {
                return -1; // Invalid loanType
            }
        }

        // Simple Interest Formula: (P * R * T) / 100
        double totalPayment =  loanAmount + ((loanAmount * interestRate * yearLoan) / 100);
        BigDecimal bd = new BigDecimal(totalPayment).setScale(2, RoundingMode.HALF_UP);
        double roundedValue = bd.doubleValue();
        return  roundedValue;
    }
    
    public static void main(String[] args) {
        double interest1 = computeLoanInterest(800000, 40, -1); 
        double interest2 = computeLoanInterest(800000, 40, 0);
        double interest3 = computeLoanInterest(800000, 40, 3);
        double interest4 = computeLoanInterest(800000, 40, 4);


        System.out.println("Test Case 1 - Interest: " + interest1);
        System.out.println("Test Case 2 - Interest: " + interest2);
        System.out.println("Test Case 3 - Interest: " + interest3);
        System.out.println("Test Case 4 - Interest: " + interest4);
    }
}

