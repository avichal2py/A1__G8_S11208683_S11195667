import a1_cs341.calcinterest.CalcInterest;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class CalcInterestTest {

    // Test case for Home Loan: loanAmount < 100,000, yearLoan <= 5
    @Test
    public void testCase_1() {
        double result = CalcInterest.computeLoanInterest(150000, 15, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_2() {
        double result = CalcInterest.computeLoanInterest(50000, 3, 1); // Home Loan
        assertEquals(62000, result, "Expected amount is 62000");
    }
    
    @Test
    public void testCase_3() {
        double result = CalcInterest.computeLoanInterest(0, 0, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_4() {
        double result = CalcInterest.computeLoanInterest(1, 1, 1); // Home Loan
        assertEquals(1.08, result, "Expected amount is 1.08");
    }
    
    @Test
    public void testCase_5() {
        double result = CalcInterest.computeLoanInterest(2, 2, 1); // Home Loan
        assertEquals(2.32, result, "Expected amount is 2.32");
    }
    
    @Test
    public void testCase_6() {
        double result = CalcInterest.computeLoanInterest(99998, 4, 1); // Home Loan
        assertEquals(131997.36, result, "Expected amount is 131997.36");
    }
    
    @Test
    public void testCase_7() {
        double result = CalcInterest.computeLoanInterest(99999, 5, 1); // Home Loan
        assertEquals(139998.6, result, "Expected amount is 139998.6");
    }
    
    @Test
    public void testCase_8() {
        double result = CalcInterest.computeLoanInterest(100000, 6, 1); // Home Loan
        assertEquals(139000, result, "Expected amount is 139000");
    }
    
    @Test
    public void testCase_9() {
        double result = CalcInterest.computeLoanInterest(-1, 2, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_10() {
        double result = CalcInterest.computeLoanInterest(50000, 8, 1); // Home Loan
        assertEquals(76000, result, "Expected amount is 76000");
    }
    
    @Test
    public void testCase_11() {
        double result = CalcInterest.computeLoanInterest(0, 5, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    @Test
    public void testCase_12() {
        double result = CalcInterest.computeLoanInterest(1, 6, 1); // Home Loan
        assertEquals(1.39, result, "Expected amount is 1.39");
    }
    
    @Test
    public void testCase_13() {
        double result = CalcInterest.computeLoanInterest(2, 7, 1); // Home Loan
        assertEquals(2.91, result, "Expected amount is 2.91");
    }
    
    @Test
    public void testCase_14() {
        double result = CalcInterest.computeLoanInterest(99998, 9, 1); // Home Loan
        assertEquals(158496.83, result, "Expected amount is 158496.83");
    }
    
    @Test
    public void testCase_15() {
        double result = CalcInterest.computeLoanInterest(99999, 10, 1); // Home Loan
        assertEquals(164998.35, result, "Expected amount is 164998.35");
    }
    
    @Test
    public void testCase_16() {
        double result = CalcInterest.computeLoanInterest(100000, 11, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_17() {
        double result = CalcInterest.computeLoanInterest(-20, 5, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_18() {
        double result = CalcInterest.computeLoanInterest(50000, 15, 1); // Home Loan
        assertEquals(91250, result, "Expected amount is 91250");
    }
    
    @Test
    public void testCase_19() {
        double result = CalcInterest.computeLoanInterest(0, 10, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_20() {
        double result = CalcInterest.computeLoanInterest(1, 11, 1); // Home Loan
        assertEquals(1.60, result, "Expected amount is 1.605");
    }
    
    @Test
    public void testCase_21() {
        double result = CalcInterest.computeLoanInterest(2, 12, 1); // Home Loan
        assertEquals(3.32, result, "Expected amount is 1.6");
    }
    
    @Test
    public void testCase_22() {
        double result = CalcInterest.computeLoanInterest(99998, 20, 1); // Home Loan
        assertEquals(209995.8, result, "Expected amount is 209995.8");
    }
    
    @Test
    public void testCase_23() {
        double result = CalcInterest.computeLoanInterest(99999, 30, 1); // Home Loan
        assertEquals(264997.35, result, "Expected amount is 264997.35");
    }
    
    @Test
    public void testCase_24() {
        double result = CalcInterest.computeLoanInterest(100000, 40, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_25() {
        double result = CalcInterest.computeLoanInterest(600000, 20, 1); // Home Loan
        assertEquals(1260000, result, "Expected amount is 1260000");
    }
    
    @Test
    public void testCase_26() {
        double result = CalcInterest.computeLoanInterest(250000, 8, 1); // Home Loan
        assertEquals(380000, result, "Expected amount is 380000");
    }
    
    @Test
    public void testCase_27() {
        double result = CalcInterest.computeLoanInterest(99999, 0, 1); // Home Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_28() {
        double result = CalcInterest.computeLoanInterest(100000, 1, 1); // Home Loan
        assertEquals(106500, result, "Expected amount is 106500");
    }
    
    @Test
    public void testCase_29() {
        double result = CalcInterest.computeLoanInterest(100001, 2, 1); // Home Loan
        assertEquals(113001.13, result, "Expected amount is 113001.13");
    }
    
    @Test
    public void testCase_30() {
        double result = CalcInterest.computeLoanInterest(499998, 9, 1); // Home Loan
        assertEquals(792496.83, result, "Expected amount is 792496.83");
    }
    
    @Test
    public void testCase_31() {
        double result = CalcInterest.computeLoanInterest(499999, 10, 1); // Home Loan
        assertEquals(824998.35, result, "Expected amount is 824998.35");
    }
    
    @Test
    public void testCase_32() {
        double result = CalcInterest.computeLoanInterest(500000, 11, 1); // Home Loan
        assertEquals(802500, result, "Expected amount is 802500");
    }
    
    @Test
    public void testCase_33() {
        double result = CalcInterest.computeLoanInterest(300000, 8, 1); // Home Loan
        assertEquals(456000, result, "Expected amount is 456000");
    }
    
    @Test
    public void testCase_34() {
        double result = CalcInterest.computeLoanInterest(800000, 15, 1); // Home Loan
        assertEquals(1460000, result, "Expected amount is 1460000");
    }
    
    @Test
    public void testCase_35() {
        double result = CalcInterest.computeLoanInterest(499999, 10, 1); // Home Loan
        assertEquals(824998.35, result, "Expected amount is 824998.35");
    }
    
    @Test
    public void testCase_36() {
        double result = CalcInterest.computeLoanInterest(500000, 11, 1); // Home Loan
        assertEquals(802500, result, "Expected amount is 802500");
    }
    
    @Test
    public void testCase_37() {
        double result = CalcInterest.computeLoanInterest(500001, 12, 1); // Home Loan
        assertEquals(830001.66, result, "Expected amount is 830001.66");
    }
    
    @Test
    public void testCase_38() {
        double result = CalcInterest.computeLoanInterest(600000, 20, 1); // Home Loan
        assertEquals(1260000, result, "Expected amount is 1260000");
    }
    
    @Test
    public void testCase_39() {
        double result = CalcInterest.computeLoanInterest(700000, 30, 1); // Home Loan
        assertEquals(1855000, result, "Expected amount is 1855000");
    }
    
    @Test
    public void testCase_40() {
        double result = CalcInterest.computeLoanInterest(800000, 40, 1); // Home Loan
        assertEquals(2560000, result, "Expected amount is 2650000");
    }
    
    @Test
    public void testCase_41() {
        double result = CalcInterest.computeLoanInterest(150000, 15, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_42() {
        double result = CalcInterest.computeLoanInterest(50000, 3, 2); // Property Loan
        assertEquals(68000, result, "Expected amount is 68000");
    }
    
    @Test
    public void testCase_43() {
        double result = CalcInterest.computeLoanInterest(0, 0, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_44() {
        double result = CalcInterest.computeLoanInterest(1, 1, 2); // Property Loan
        assertEquals(1.12, result, "Expected amount is 1.12");
    }
    
    @Test
    public void testCase_45() {
        double result = CalcInterest.computeLoanInterest(2, 2, 2); // Property Loan
        assertEquals(2.48, result, "Expected amount is 2.48");
    }
    
    @Test
    public void testCase_46() {
        double result = CalcInterest.computeLoanInterest(99998, 4, 2); // Property Loan
        assertEquals(147997.04, result, "Expected amount is 147997.04");
    }
    
    @Test
    public void testCase_47() {
        double result = CalcInterest.computeLoanInterest(99999, 5, 2); // Property Loan
        assertEquals(159998.4, result, "Expected amount is 159998.4");
    }
    
    @Test
    public void testCase_48() {
        double result = CalcInterest.computeLoanInterest(100000, 6, 2); // Property Loan
        assertEquals(151000, result, "Expected amount is 151000");
    }
    
    @Test
    public void testCase_49() {
        double result = CalcInterest.computeLoanInterest(150000, 3, 2); // Property Loan
        assertEquals(188250, result, "Expected amount is 188250");
    }
    
    @Test
    public void testCase_50() {
        double result = CalcInterest.computeLoanInterest(50000, 8, 2); // Property Loan
        assertEquals(84000, result, "Expected amount is 84000");
    }
    
    @Test
    public void testCase_51() {
        double result = CalcInterest.computeLoanInterest(0, 5, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_52() {
        double result = CalcInterest.computeLoanInterest(1, 6, 2); // Property Loan
        assertEquals(1.51, result, "Expected amount is 1.51");
    }
    
    @Test
    public void testCase_53() {
        double result = CalcInterest.computeLoanInterest(2, 7, 2); // Property Loan
        assertEquals(3.19, result, "Expected amount is 3.19");
    }
    
    @Test
    public void testCase_54() {
        double result = CalcInterest.computeLoanInterest(99998, 8, 2); // Property Loan
        assertEquals(167996.64, result, "Expected amount is 167996.64");
    }
    
    @Test
    public void testCase_55() {
        double result = CalcInterest.computeLoanInterest(99999, 9, 2); // Property Loan
        assertEquals(176498.23, result, "Expected amount is 176498.23");
    }
    
    @Test
    public void testCase_56() {
        double result = CalcInterest.computeLoanInterest(100000, 10, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_57() {
        double result = CalcInterest.computeLoanInterest(-20, 5, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_58() {
        double result = CalcInterest.computeLoanInterest(50000, 15, 2); // Property Loan
        assertEquals(102500, result, "Expected amount is 102500");
    }
    
    @Test
    public void testCase_59() {
        double result = CalcInterest.computeLoanInterest(0, 10, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_60() {
        double result = CalcInterest.computeLoanInterest(1, 11, 2); // Property Loan
        assertEquals(1.77, result, "Expected amount is 1.77");
    }
    
    @Test
    public void testCase_61() {
        double result = CalcInterest.computeLoanInterest(2, 12, 2); // Property Loan
        assertEquals(3.68, result, "Expected amount is 3.68");
    }
    
    @Test
    public void testCase_62() {
        double result = CalcInterest.computeLoanInterest(99998, 20, 2); // Property Loan
        assertEquals(239995.2, result, "Expected amount is 239995.2");
    }
    
    @Test
    public void testCase_63() {
        double result = CalcInterest.computeLoanInterest(99999, 30, 2); // Property Loan
        assertEquals(309996.9, result, "Expected amount is 309996.9");
    }
    
    @Test
    public void testCase_64() {
        double result = CalcInterest.computeLoanInterest(100000, 40, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_65() {
        double result = CalcInterest.computeLoanInterest(600000, 20, 2); // Property Loan
        assertEquals(1440000, result, "Expected amount is 1440000");
    }
    
    @Test
    public void testCase_66() {
        double result = CalcInterest.computeLoanInterest(250000, 8, 2); // Property Loan
        assertEquals(420000, result, "Expected amount is 420000");
    }
    
    @Test
    public void testCase_67() {
        double result = CalcInterest.computeLoanInterest(99999, 0, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_68() {
        double result = CalcInterest.computeLoanInterest(100000, 1, 2); // Property Loan
        assertEquals(108500, result, "Expected amount is 108500");
    }
    
    @Test
    public void testCase_69() {
        double result = CalcInterest.computeLoanInterest(100001, 2, 2); // Property Loan
        assertEquals(117001.17, result, "Expected amount is 117001.17");
    }
    
    @Test
    public void testCase_70() {
        double result = CalcInterest.computeLoanInterest(499998, 8, 2); // Property Loan
        assertEquals(839996.64, result, "Expected amount is 839996.64");
    }
    
    @Test
    public void testCase_71() {
        double result = CalcInterest.computeLoanInterest(499999, 9, 2); // Property Loan
        assertEquals(882498.23, result, "Expected amount is 882498.23");
    }
    
    @Test
    public void testCase_72() {
        double result = CalcInterest.computeLoanInterest(500000, 10, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_73() {
        double result = CalcInterest.computeLoanInterest(300000, 8, 2); // Property Loan
        assertEquals(504000, result, "Expected amount is 504000");
    }
    
    @Test
    public void testCase_74() {
        double result = CalcInterest.computeLoanInterest(800000, 15, 2); // Property Loan
        assertEquals(1640000, result, "Expected amount is 1640000");
    }
    
    @Test
    public void testCase_75() {
        double result = CalcInterest.computeLoanInterest(499999, 10, 2); // Property Loan
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_76() {
        double result = CalcInterest.computeLoanInterest(500000, 11, 2); // Property Loan
        assertEquals(885000, result, "Expected amount is 885000");
    }
    
    @Test
    public void testCase_77() {
        double result = CalcInterest.computeLoanInterest(500001, 12, 2); // Property Loan
        assertEquals(920001.84, result, "Expected amount is 920001.84");
    }
    
    @Test
    public void testCase_78() {
        double result = CalcInterest.computeLoanInterest(600000, 20, 2); // Property Loan
        assertEquals(1440000, result, "Expected amount is 1440000");
    }
    
    @Test
    public void testCase_79() {
        double result = CalcInterest.computeLoanInterest(700000, 30, 2); // Property Loan
        assertEquals(2170000, result, "Expected amount is 2170000");
    }
    
    @Test
    public void testCase_80() {
        double result = CalcInterest.computeLoanInterest(800000, 40, 2); // Property Loan
        assertEquals(3040000, result, "Expected amount is 3040000");
    }
    
    @Test
    public void testCase_81() {
        double result = CalcInterest.computeLoanInterest(800000, 40, -1); // Invalid loanType
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_82() {
        double result = CalcInterest.computeLoanInterest(800000, 40, 0); // Invalid loanType
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_83() {
        double result = CalcInterest.computeLoanInterest(800000, 40, 3); // Invalid loanType
        assertEquals(-1, result, "Expected amount is -1");
    }
    
    @Test
    public void testCase_84() {
        double result = CalcInterest.computeLoanInterest(800000, 40, 4); // Invalid loanType
        assertEquals(-1, result, "Expected amount is -1");
    }
}

